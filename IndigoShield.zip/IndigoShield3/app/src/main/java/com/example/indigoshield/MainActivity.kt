package com.example.indigoshield

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Telephony
import android.speech.*
import android.telephony.SmsManager
import android.view.KeyEvent
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.background
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ButtonDefaults

class MainActivity : ComponentActivity() {

    private val guardianNumber = "+919036998405"

    private lateinit var speechRecognizer: SpeechRecognizer
    private lateinit var speechIntent: Intent

    private var volumePressTime: Long = 0
    private var emergencyTriggered = false

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        permissionLauncher.launch(
            arrayOf(
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.CALL_PHONE,
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.SEND_SMS,
                Manifest.permission.RECEIVE_SMS,
                Manifest.permission.READ_SMS,
                Manifest.permission.READ_PHONE_STATE
            )
        )

        // 🔥 Ask to become default SMS app


        setupSpeechRecognizer()

        setContent {
            SOSScreen(
                onManualSOS = { triggerEmergency() },
                onStartListening = { startListening() }
            )
        }
    }

    // ---------------- VOICE ----------------

    private fun setupSpeechRecognizer() {

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)

        speechIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        speechIntent.putExtra(
            RecognizerIntent.EXTRA_LANGUAGE_MODEL,
            RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
        )

        speechRecognizer.setRecognitionListener(object : RecognitionListener {

            override fun onResults(results: Bundle?) {

                val matches =
                    results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)

                if (!matches.isNullOrEmpty()) {
                    val spokenText = matches[0].lowercase()

                    if (spokenText.contains("help") ||
                        spokenText.contains("indigo")
                    ) {
                        triggerEmergency()
                        return
                    }
                }

                restartListening()
            }

            override fun onError(error: Int) {
                restartListening()
            }

            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
    }

    private fun startListening() {
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            speechRecognizer.startListening(speechIntent)
            Toast.makeText(this, "Voice Monitoring Started", Toast.LENGTH_SHORT).show()
        }
    }

    private fun restartListening() {
        speechRecognizer.cancel()
        speechRecognizer.startListening(speechIntent)
    }

    // ---------------- EMERGENCY ----------------

    private fun triggerEmergency() {

        if (emergencyTriggered) return
        emergencyTriggered = true

        Toast.makeText(this, "🚨 SOS Triggered!", Toast.LENGTH_SHORT).show()

        sendAutoSMS()

        Handler(Looper.getMainLooper()).postDelayed({
            makeEmergencyCall()
            emergencyTriggered = false
        }, 5000)
    }

    // ---------------- SMS ----------------

    private fun sendAutoSMS() {

        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            Toast.makeText(this, "SMS Permission Missing", Toast.LENGTH_SHORT).show()
            return
        }

        val location = getBestLocation()

        var message = "🚨 SOS ALERT!\nI need help immediately."

        if (location != null) {
            message += "\n\nLocation:\nhttps://maps.google.com/?q=${location.latitude},${location.longitude}"
        }

        try {

            val smsManager =
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    getSystemService(SmsManager::class.java)
                } else {
                    SmsManager.getDefault()
                }

            val parts = smsManager.divideMessage(message)

            smsManager.sendMultipartTextMessage(
                guardianNumber,
                null,
                parts,
                null,
                null
            )

            Toast.makeText(this, "SMS Sent Successfully", Toast.LENGTH_SHORT).show()

        } catch (e: Exception) {
            Toast.makeText(this, "SMS Failed: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    // ---------------- CALL ----------------

    private fun makeEmergencyCall() {

        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.CALL_PHONE
            ) != PackageManager.PERMISSION_GRANTED
        ) return

        startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:$guardianNumber")))
    }

    // ---------------- LOCATION ----------------

    private fun getBestLocation(): Location? {

        val manager =
            getSystemService(Context.LOCATION_SERVICE) as LocationManager

        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) return null

        return manager.getLastKnownLocation(LocationManager.GPS_PROVIDER)
            ?: manager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
    }

    // ---------------- VOLUME LONG PRESS ----------------

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {

        if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN ||
            keyCode == KeyEvent.KEYCODE_VOLUME_UP
        ) {
            if (volumePressTime == 0L) {
                volumePressTime = System.currentTimeMillis()
            }
            return true
        }

        return super.onKeyDown(keyCode, event)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent?): Boolean {

        if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN ||
            keyCode == KeyEvent.KEYCODE_VOLUME_UP
        ) {

            val pressDuration =
                System.currentTimeMillis() - volumePressTime

            volumePressTime = 0

            if (pressDuration > 1500) {
                triggerEmergency()
            }

            return true
        }

        return super.onKeyUp(keyCode, event)
    }

    override fun onDestroy() {
        super.onDestroy()
        speechRecognizer.destroy()
    }
}

@Composable
fun SOSScreen(
    onManualSOS: () -> Unit,
    onStartListening: () -> Unit
) {

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF1E1E2E),
                        Color(0xFF2A2A40)
                    )
                )
            ),
        contentAlignment = Alignment.Center
    ) {

        Column(
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            Text(
                text = "INDIGO SHIELD",
                color = Color.White,
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(40.dp))

            // 🔴 BIG SOS BUTTON
            Button(
                onClick = onManualSOS,
                shape = CircleShape,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color.Red
                ),
                modifier = Modifier
                    .size(180.dp)
            ) {
                Text(
                    text = "SOS",
                    fontSize = 30.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }

            Spacer(modifier = Modifier.height(40.dp))

            // 🎤 Voice Monitoring Button
            Button(
                onClick = onStartListening,
                shape = RoundedCornerShape(50.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF6C5CE7)
                ),
                modifier = Modifier
                    .width(240.dp)
                    .height(60.dp)
            ) {
                Text(
                    text = "Start Voice Monitoring",
                    fontSize = 16.sp,
                    color = Color.White
                )
            }
        }
    }
}